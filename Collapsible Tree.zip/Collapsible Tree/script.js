$(document).ready(function() {
    $('.level-1 > li').click(function() {
        // Toggle the visibility of the child ul
        $(this).find('.level-2').slideToggle();

        // Collapse other level-2 items
        $(this).siblings().find('.level-2').slideUp();
    });
});